from django.contrib import admin
from .models import Matches, Messages

admin.site.register(Matches)
admin.site.register(Messages)