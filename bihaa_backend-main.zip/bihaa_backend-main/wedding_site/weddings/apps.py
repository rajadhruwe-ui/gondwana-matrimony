from django.apps import AppConfig


class WeddingsConfig(AppConfig):
    name = 'weddings'
