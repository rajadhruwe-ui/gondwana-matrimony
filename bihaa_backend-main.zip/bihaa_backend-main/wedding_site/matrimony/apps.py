from django.apps import AppConfig


class MatrimonyConfig(AppConfig):
    name = 'matrimony'
